OceanWP Child Theme
=================

Child Theme for the OceanWP WordPress theme.

### Usage
Simply download the zip and upload the zip (oceanwp-child-theme-master.zip) under your WordPress dashboard at Appearance > Themes. Or extract and upload via FTP at wp-content/themes/.


### Renaming
You can of course rename the zip file so it isn't called oceanwp-child-theme-master.zip (you should do this so it makes more sense) and also change the "Theme Name" at the top of the style.css file.
