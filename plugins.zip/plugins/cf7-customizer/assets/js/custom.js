/**
* Custom JS
*
* @package AA
*
*/

jQuery(function($){

	jQuery(document).ready(function($) {

		// Set the id and class
	    $('.wpcf7').attr('id','cfc');

	});


// End
});





